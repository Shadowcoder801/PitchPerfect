//
//  RecordSoundsViewController.swift
//  PitchPerfect
//
//  Created by Kyle Humphrey on 6/8/17.
//  Copyright © 2017 Humphrey Corporations. All rights reserved.
//

import UIKit
import Foundation
import AVFoundation

class RecordSoundsViewController: UIViewController, AVAudioRecorderDelegate
{
    var audioRecorder: AVAudioRecorder!
    
    @IBOutlet weak var recordButton: UIButton!
    @IBOutlet weak var recordLabel: UILabel!
    @IBOutlet weak var stopRecordingButton: UIButton!
    
    @IBAction func recordAudio(_ sender: AnyObject)
    {
        /*
         Activated when the record button is pressed
         Disables the record button and enables to the stop button
         Records audio from the microphone
         */
        
        configureUI(true)
        
        recordSounds();
    }

    
    func recordSounds()
    {
        /*
         Records the audio from the microphone to be played back
         Stores the recorded audio as a file RecordedVoice.wav
         */
        
        let dirPath = NSSearchPathForDirectoriesInDomains(.documentDirectory,.userDomainMask, true)[0] as String
        let recordingName = "recordedVoice.wav"
        let pathArray = [dirPath, recordingName]
        let filePath = URL(string: pathArray.joined(separator: "/"))
        
        let session = AVAudioSession.sharedInstance()
        try! session.setCategory(AVAudioSessionCategoryPlayAndRecord, with:AVAudioSessionCategoryOptions.defaultToSpeaker)
        
        try! audioRecorder = AVAudioRecorder(url: filePath!, settings: [:])
        audioRecorder.delegate = self;
        audioRecorder.isMeteringEnabled = true
        audioRecorder.prepareToRecord()
        audioRecorder.record()
    }
    
    @IBAction func stopRecording(_ sender: AnyObject)
    {
        /*
         Activates when the stop button is pressed
         If pressed before recording it will play back from an exisiting RecordedVoice.wav file
         If pressed after recoridng it will use the new RecordedVoice.wav file to play back
         Either way it will also perform the transition to the Play Sounds View Controller
         */
        
        configureUI(false)
            
        audioRecorder.stop();
        let audioSession = AVAudioSession.sharedInstance();
        try! audioSession.setActive(false);
    }
    
    func audioRecorderDidFinishRecording(_ recorder: AVAudioRecorder, successfully flag: Bool)
    {
        /*
         Method to make sure the view transition happens after the audio has successfully recorded and stopped
         Prints a console message if the recording failed to save into a file
         */
        
        if flag
        {
            performSegue(withIdentifier: "stopRecording", sender: audioRecorder.url)
        }
        else
        {
            print("Recording failed to save");
        }
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?)
    {
        /*
         Transitions to the next view
         Gets the URL from the audio recording file
         Transfers that URL to the recordedAudioURL variable in the new View Controller
         */
        
        if segue.identifier == "stopRecording"
        {
            let playSoundsVC = segue.destination as! PlaySoundsViewController;
            let recordedAudioURL = sender as! URL;
            playSoundsVC.recordedAudioURL = recordedAudioURL;
        }
    }
    
    func configureUI(_ isRecording : Bool)
    {
        /*
            Changes the enablement or disenablement of the buttons and labels in the RecordSoundsViewController
            Enables the stop button during recording
            Disables the stop button pre-recording
        */
        
        recordLabel.text = isRecording ? "Recording in progress..." : "Tap to Record"
        recordButton.isEnabled = !isRecording
        stopRecordingButton.isEnabled = isRecording
    }
    
    override func viewWillAppear(_ animated: Bool)
    {
        super.viewWillAppear(animated)
        stopRecordingButton.isEnabled = false
    }
}

