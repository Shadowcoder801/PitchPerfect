//
//  PlaySoundsViewController.swift
//  PitchPerfect
//
//  Created by Kyle Humphrey on 6/13/17.
//  Copyright © 2017 Humphrey Corporations. All rights reserved.
//

import UIKit
import AVFoundation

class PlaySoundsViewController: UIViewController
{
    
    // Button Outlets
    
    @IBOutlet weak var snailButton : UIButton!
    @IBOutlet weak var rabbitButton : UIButton!
    @IBOutlet weak var chipmunkButton : UIButton!
    @IBOutlet weak var vaderButton : UIButton!
    @IBOutlet weak var echoButton : UIButton!
    @IBOutlet weak var reverbButton : UIButton!
    @IBOutlet weak var stopButton : UIButton!
    
    @IBOutlet weak var snailLabel : UILabel!
    @IBOutlet weak var rabbitLabel : UILabel!
    @IBOutlet weak var chipmunkLabel : UILabel!
    @IBOutlet weak var vaderLabel : UILabel!
    @IBOutlet weak var echoLabel : UILabel!
    @IBOutlet weak var reverbLabel : UILabel!
    
    
    
    
    
    
    // URL for Audio
    
    var recordedAudioURL : URL!
    
    // Audio Variables
    
    var audioFile : AVAudioFile!
    var audioEngine : AVAudioEngine!
    var audioPlayerNode : AVAudioPlayerNode!
    var stopTimer : Timer!
    
    
    // Sound Variables
    
    var tempo = Float(1.0)
    var pitchRate = Float(0)
    var willEcho = false
    var willReverb = false
    
    // Status Variables
    var isPlaying = false
    
    
    // Enumeration for each button
    
    enum ButtonType: Int
    {
        case slow = 0, fast, chipmunk, vader, echo, reverb
    }
    
    // Function for playing each button
    
    @IBAction func playSoundsForButton(_ sender: UIButton)
    {
        /*
         Plays the audio with an effect depending on the button tag
         The tag is put into the enum for the buttons and plays a different effect for each ButtonType
         The effects affect the tempo, pitch, echo, and reverb of the audio
         Keeps playing if there is an sound effect on
         Does not play if all buttons are off
         */
        
        if (isPlaying)
        {
            stopButtonPressed(sender)
        }
        
        switch(ButtonType(rawValue: sender.tag)!)
        {
        case .slow:
            slowButtonPressed()
        case .fast:
            fastButtonPressed()
        case .chipmunk:
            highPitchButtonPressed()
        case .vader:
            lowPitchButtonPressed()
        case .echo:
            echoButtonPressed()
        case .reverb:
            reverbButtonPressed()
        }
        
        if (allButtonsAreOff())
        {
            isPlaying = false
            stopButton.isEnabled = false
        }
        else
        {
            playSound(tempo, pitch: pitchRate, echo: willEcho, reverb: willReverb)
            
            isPlaying = true
            stopButton.isEnabled = true
        }
    }
    
    
    // Sounds Effects Functions
    /*
        Unfortunately I divided this into six different methods because I do not know how to make
        objects that can hold both a button, its label, and a SFX value.
        I trust that I will learn how to make that kind of object as I go along
        If a SFX mode is on, it pressing it will turn the sound effect off
        If a SFX mode is off, pressing it will turn it on and turn the opposing sound effect off
    */
    
    func slowButtonPressed()
    {
        if (tempo == 0.5)
        {
            turnTextWhite(label: snailLabel)
            tempo = 1
        }
        else
        {
            turnTextBlackThenWhite(black: snailLabel, white: rabbitLabel)
            tempo = 0.5
        }
    }
    
    func fastButtonPressed()
    {
        if (tempo == 1.5)
        {
            turnTextWhite(label: rabbitLabel)
            tempo = 1
        }
        else
        {
            turnTextBlackThenWhite(black: rabbitLabel, white: snailLabel)
            tempo = 1.5
        }
    }
    
    func highPitchButtonPressed()
    {
        if (pitchRate == 1000)
        {
            turnTextWhite(label: chipmunkLabel)
            pitchRate = 0
        }
        else
        {
            turnTextBlackThenWhite(black: chipmunkLabel, white: vaderLabel)
            pitchRate = 1000
        }
    }
    
    func lowPitchButtonPressed()
    {
        if (pitchRate == -1000)
        {
            turnTextWhite(label: vaderLabel)
            pitchRate = 0
        }
        else
        {
            turnTextBlackThenWhite(black: vaderLabel, white: chipmunkLabel)
            pitchRate = -1000
        }
    }
    
    func echoButtonPressed()
    {
        if (willEcho)
        {
            turnTextWhite(label: echoLabel)
            willEcho = false
        }
        else
        {
            turnTextBlack(label: echoLabel)
            willEcho = true
        }
    }
    
    func reverbButtonPressed()
    {
        if (willReverb)
        {
            turnTextWhite(label: reverbLabel)
            willReverb = false
        }
        else
        {
            turnTextBlack(label: reverbLabel)
            willReverb = true
        }
    }
    
    
    // Color Functions
    /*
        Changes the color of certain labels
    */
    
    func turnTextWhite(label: UILabel)
    {
        label.textColor = UIColor(colorLiteralRed: 255, green: 255, blue: 255, alpha: 255)
    }
    
    func turnTextBlack(label: UILabel)
    {
        label.textColor = UIColor(colorLiteralRed: 0, green: 0, blue: 0, alpha: 255)
    }
    
    func turnTextBlackThenWhite(black: UILabel, white: UILabel)
    {
        black.textColor = UIColor(colorLiteralRed: 0, green: 0, blue: 0, alpha: 255)
        white.textColor = UIColor(colorLiteralRed: 255, green: 255, blue: 255, alpha: 255)
    }
    
    
    
    
    
    
    
    // Turns off All Buttons
    
    func turnOffAllButtons()
    {
        /*
            Deactivates all buttons and removes any sound effects from playback
            Turns all button's label colors to white
            Sets all sound effects variables to their default value
        */
        
        snailLabel.textColor = UIColor(colorLiteralRed: 255, green: 255, blue: 255, alpha: 255)
        rabbitLabel.textColor = UIColor(colorLiteralRed: 255, green: 255, blue: 255, alpha: 255)
        chipmunkLabel.textColor = UIColor(colorLiteralRed: 255, green: 255, blue: 255, alpha: 255)
        vaderLabel.textColor = UIColor(colorLiteralRed: 255, green: 255, blue: 255, alpha: 255)
        echoLabel.textColor = UIColor(colorLiteralRed: 255, green: 255, blue: 255, alpha: 255)
        reverbLabel.textColor = UIColor(colorLiteralRed: 255, green: 255, blue: 255, alpha: 255)
        
        tempo = 1
        pitchRate = 0
        willEcho = false
        willReverb = false
    }
    
    func allButtonsAreOff() -> Bool
    {
        /*
            Checks if all SFX variables are in their default value
        */
        
        return (tempo == 1 && pitchRate == 0 && !willEcho && !willReverb)
    }
    
    @IBAction func backButtonPressed(_ sender: UIButton)
    {
        /*
            Pressing the back button activates a segue back to the first view controller
            But it also stops audio from being played
        */
        
        if isPlaying
        {
            stopAudio()
        }
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?)
    {
        /*
         Transitions to the next view
         Gets the URL from the audio recording file
         Transfers that URL to the recordedAudioURL variable in the new View Controller
         */
        
        
    }
    
    @IBAction func playButtonPressed(_ sender: UIButton)
    {
        /*
            Plays audio with the current effects on
            Can play audio with no effects
            If audio is playing, this function stops the audio and plays again
        */
        
        if (isPlaying)
        {
            stopAudio()
        }
        
        playSound(tempo, pitch: pitchRate, echo: willEcho, reverb: willReverb)
        
        isPlaying = true
        stopButton.isEnabled = true
    }
    
    
    // Stop Button
    
    @IBAction func stopButtonPressed(_ sender: UIButton)
    {
        /*
            Stops audio and changes status variables so that it is not playing
            Disables stop button from being pressed again
        */
        
        stopAudio()
        stopButton.isEnabled = false
        isPlaying = false
    }
    
    
    // Set up functions
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        setupAudio()
    }

    override func viewWillAppear(_ animated: Bool)
    {
        super.viewWillAppear(animated)
        
        turnOffAllButtons()
    }
    
    /*
     // MARK: - Navigation
     
     // In a storyboard-based application, you will often want to do a little preparation before navigation
     override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
     // Get the new view controller using segue.destinationViewController.
     // Pass the selected object to the new view controller.
     }
     */
    
}
